<template>
  <div class="d3Animation">
    <div class="answer">
      <div align="center">
        <button
          id="start"
          type="button"
          class="btn btn-outline-secondary btn-sm"
        >
          Start
        </button>
        <button
          id="reset"
          type="button"
          class="btn btn-outline-secondary btn-sm ml-2"
        >
          Reset
        </button>
      <div>
        <svg id="chart" ></svg>
      </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as d3 from "d3";

export default {
  name: "d3Animation",
  data: function () {
    return {
      D3AnimationData: null,
    };
  },
  methods: {
    D3Animation() {
      var funding = this.D3AnimationData[0];
      var total_funding = this.D3AnimationData[1];
      // set the dimensions and margins of the graph
      var margin = { top: 50, right: 50, bottom: 30, left: 50 },
        width = 760 - margin.left - margin.right,
        height = 300 - margin.top - margin.bottom;
      // parse the year / time
      var parseTime = d3.timeParse("%Y");

      // set the ranges
      var x = d3.scaleTime().range([0 + 10, width - 10]);
      var y0 = d3.scaleLinear().range([height, 0]);
      var y1 = d3.scaleLinear().range([height, 0]);

      // define the 1st line - suppression
      var suppLine = d3
        .line()
        .x(function (d) {
          return x(parseTime(d.year));
        })
        .y(function (d) {
          return y0(d.suppression);
        });

      // define the 2nd line - fuel reduction
      var fuelLine = d3
        .line()
        .x(function (d) {
          return x(parseTime(d.year));
        })
        .y(function (d) {
          return y0(d.fuel);
        });

      // append the svg obgect to the body of the page
      // appends a 'group' element to 'svg'
      // moves the 'group' element to the top left margin
      var svg = d3
        .select("#chart")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

      // Scale the range of the data
      x.domain(
        d3.extent(funding, function (d) {
          return parseTime(d.year);
        })
      );
      y0.domain([0, 100]);

      // Add the X Axis
      var xAxis = d3.axisBottom().scale(x).ticks(22);

      svg
        .append("g")
        .attr("transform", "translate(0," + height + ")")
        .attr("z-index", "100")
        .attr("class", "axisBottom")
        .call(xAxis);

      // Add the LEFT Axis
      var y0Axis = d3.axisLeft().scale(y0).ticks(5);

      svg
        .append("g")
        .attr("class", "axisLeft")
        .attr("z-index", "100")
        .call(y0Axis);

      var x1 = d3
        .scaleBand()
        .domain(total_funding.map((d) => parseTime(d.Year)))
        .range([0, width])
        .paddingInner(0.4)
        .paddingOuter(0);

      var formatValue = d3.format(".1s");

      y1.domain([0, d3.max(total_funding, (d) => d.Total)]).nice();

      var y1Axis = d3
        .axisRight()
        .ticks(5)
        .scale(y1)
        .tickFormat((d) => formatValue(d).replace("G", "B"));

      // Add the RIGHT Axis
      svg
        .append("g")
        .attr("class", "axisRight")
        .attr("transform", "translate( " + width + ", 0 )")
        .attr("z-index", "100")
        .call(y1Axis);

      svg
        .selectAll(".bar")
        .data(total_funding, (d) => parseTime(d.Year))
        .enter()
        .append("rect")
        .attr("fill", "#dfc27d")
        .attr("opacity", 1)
        .attr("class", "bar")
        .attr("z-index", "1")
        .attr("x", (d) => x1(parseTime(d.Year)))
        .attr("y", (d) => y1(d.Total))
        .attr("width", x1.bandwidth())
        .attr("height", (d) => height - y1(d.Total));

      // Start Animation on Click
      d3.select("#start").on("click", function () {
        // Add the suppLine path.
        var path1 = svg
          .append("path")
          .data([funding])
          .attr("fill", "none")
          .attr("stroke-width", "2px")
          .attr("class", "line")
          .attr("d", suppLine)
          .attr("stroke", "#a6611a");

        // Add the fuelLine path.
        var path2 = svg
          .append("path")
          .data([funding])
          .attr("stroke-width", "2px")
          .attr("fill", "none")
          .attr("class", "line")
          .style("stroke", "#018571")
          .attr("d", fuelLine);

        // Variable to Hold Total Length
        var totalLength = path1.node().getTotalLength();
        console.log(totalLength);
        // Set Properties of Dash Array and Dash Offset and initiate Transition
        path1
          .attr("stroke-dasharray", totalLength + " " + totalLength)
          .attr("stroke-dashoffset", totalLength)
          .transition()
          .duration(4000)
          .ease(d3.easeLinear)
          .attr("stroke-dashoffset", 0);

        // Variable to Hold Total Length
        var totalLength = path2.node().getTotalLength();

        // Set Properties of Dash Array and Dash Offset and initiate Transition
        path2
          .attr("stroke-dasharray", totalLength + " " + totalLength)
          .attr("stroke-dashoffset", totalLength)
          .transition()
          .duration(4000)
          .ease(d3.easeLinear)
          .attr("stroke-dashoffset", 0); // Set final value of dash-offset for transition
      });

      // Reset Animation
      d3.select("#reset").on("click", function () {
        d3.selectAll(".line").remove();
      });

      // y Left label
      svg
        .append("text")
        .attr("x", - height * 0.665)
        .attr("y", - margin.left * 0.6)
        .attr("transform", "rotate(-90)")
        .attr("class", "label")
        .append("tspan")
        .text("% of total funding")
        .style("font-size", "0.7em");

      // y Right label
      svg
        .append("text")
        .attr("x", height * 0.25)
        .attr("y", - width - 30)
        .attr("transform", "rotate(90)")
        .attr("class", "label")
        .append("tspan")
        .text("Total Funding (billions)")
        .style("font-size", "0.7em");

      // Title
      svg
        .append("text")
        .attr("x", width / 2)
        .attr("text-anchor", "middle")
        .attr("transform", "rotate(0)")
        .style("font-size", "1em")
        .attr("class", "title")
        .append("tspan")
        .text("Suppression vs. Prevention Funding");

      // Legend
      svg
        .append("text")
        .attr("x", 80)
        .attr("y", 30)
        .attr("transform", "rotate(0)")
        .attr("class", "legend")
        .append("tspan")
        .text("Prevention Funding")
        .style("font-size", "0.7em")
        .attr("stroke","#4a6886");

      svg
        .append("text")
        .attr("x", 80)
        .attr("y", 45)
        .attr("transform", "rotate(0)")
        .attr("class", "legend")
        .append("tspan")
        .text("Suppression Funding")
        .style("font-size", "0.7em")
        .attr("stroke","#4a6886");

      svg
        .append("text")
        .attr("x", 80)
        .attr("y", 60)
        .attr("transform", "rotate(0)")
        .attr("class", "legend")
        .append("tspan")
        .text("Total Funding")
        .style("font-size", "0.7em")
        .attr("stroke","#4a6886");

      svg
        .append("line")
        .style("stroke", "#018571")
        .attr("x1", 60)
        .attr("y1", 25)
        .attr("x2", 73)
        .attr("y2", 25)
        .attr("stroke-width", 2.5);

      svg
        .append("line")
        .style("stroke", "#a6611a")
        .attr("x1", 60)
        .attr("y1", 40)
        .attr("x2", 73)
        .attr("y2", 40)
        .attr("stroke-width", 2.5);

      svg
        .append("rect")
        .attr("fill", "#dfc27d")
        .attr("opacity", 1)
        .attr("x", 61.5)
        .attr("y", 52)
        .attr("width", 10)
        .attr("height", 10);

      svg
        .append("line")
        .style("stroke", "black")
        .attr("x1", 0)
        .attr("y1", height +0.5)
        .attr("x2", 10)
        .attr("y2", height +0.5)
        .attr("stroke-width", 0.5);

      svg
        .append("line")
        .style("stroke", "black")
        .attr("x1", width - 20)
        .attr("y1", height +0.5)
        .attr("x2", width)
        .attr("y2", height +0.5)
        .attr("stroke-width", 0.5);
    },
  },
  mounted: function () {
    console.log("mounted");

    if (!this.$store.state.vueD3AnimationData) {
      var promises = [];
      var files = ["funding.json", "total_funding.json"];
      files.forEach((url) => promises.push(d3.json(url)));

      Promise.all(promises).then((data) => {
        this.D3AnimationData = data;
        this.$store.commit("vueD3AnimationData", this.D3AnimationData);
        //plot the chart
        this.D3Animation();
      });
    } else {
      this.D3AnimationData = this.$store.state.vueD3AnimationData;

      //plot the chart
      this.D3Animation();
    }
  },
};
</script>

<!-- "scoped" attribute limits CSS to this component only -->
<style scoped>
>>> .line {
  fill: none;
  stroke-width: 2px;
}

>>> .title {
  fill: rgb(31, 31, 31);
}

>>> .legend {
  fill: rgb(51, 51, 51);
}

>>> .axisLeft text {
  fill: rgb(107, 107, 107);
}

>>> .axisRight text {
  fill: rgb(107, 107, 107);
}

>>> .axisBottom text {
  fill: rgb(107, 107, 107);
}
</style>
