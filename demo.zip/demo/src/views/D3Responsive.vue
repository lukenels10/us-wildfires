<template>
    <div>  
        <h1 class='section'>2. Stacked Bar Chart: Seasonality of Fire Causes</h1>
        <svg id="chart2" width="100%" height="350px"></svg>
        <!-- <script src="seasonality.js"></script> -->
    </div>
</template>

<script>
import * as d3 from 'd3';

export default {
    name: 'd3Responsive',
    data: function () {
        return {
            seasonalityData: null,
        }
    },
    methods: {
        D3Responsive() {
            var data = this.seasonalityData;

            var svg_elem = d3.select('#chart2'),
                outer_width = parseInt(svg_elem.style('width')),
                outer_height = parseInt(svg_elem.style('height'));

            var margin = {top: 10, right: 130, bottom: 30, left: 150},
                inner_width =  outer_width - margin.left - margin.right,
                inner_height = outer_height - margin.top - margin.bottom;

            var svg = svg_elem
                    .append('g')
                    .attr('transform', 'translate(' + margin.left + ', ' + margin.top + ')');

            var series = d3.stack()
                .keys(this.seasonalityData.columns.slice(1))
                (this.seasonalityData)
                .map(d => (d.forEach(v => v.key = d.key), d));

            var legends = series.map(d => d.key);

            var color = d3.scaleOrdinal()
                .domain(series.map(d => d.key))
                // .range(d3.schemeSpectral[series.length])
                .range(["#FB8072", "#FDB462", "#FFFFB3", "#8DD3C7", "#80B1D3", "#BEBADA"])
                .unknown("#ccc");

            var x = d3.scaleBand()
                .round(true)
                .paddingInner(0.05)
                .domain(this.seasonalityData.map(d => d.month))
                .range([0, inner_width]);
            
            svg.append("g")
                .attr('class', 'x axis')
                .attr("transform", "translate(0," + inner_height + ")")
                .call(d3.axisBottom(x));

            var y = d3.scaleLinear()
                // .domain([0, d3.max(series, d => d3.max(d, d => d[1]))])
                .domain([0, 1])
                .range([inner_height, 0])
                .nice();

            // y-axis label
            svg.append("g")
                .attr('class', 'y axis')
                .call(d3.axisLeft(y))
                .append('text')
                .attr('transform', 'rotate(-90)')
                .attr('x', -30)
                .attr('y', -30)
                .style('font-size', '15')
                .style('fill', '#fee0d2')
                .text('Percentage');

            svg.selectAll('.line')
                .data(this.seasonalityData)
                .enter()
                .append('line')
                .attr('class', 'line')
                .attr('x1', d => x(d.month) + x.bandwidth() / 2)
                .attr('y1', inner_height)
                .attr('x2', d => x(d.month) + x.bandwidth() / 2)
                .attr('y2', d => y(d3.sum(legends.map(k => d[k]))))
                .attr('stroke', '#aaa')
                .attr('stroke-width', '3px');

            svg.append("g")
                .selectAll("g")
                .data(series)
                .enter()
                .append('g')
                .attr('id', 'g-circle')
                .attr("fill", d => color(d.key))
                .selectAll("circle")
                .data(d => d)
                .enter()
                .append("circle")
                .attr('class', 'circle')
                .attr("cx", d => x(d.data.month) + x.bandwidth() / 2)
                .attr("cy", d => y(d[1]))
                .attr("r", 5);

            svg.append("g")
                .selectAll("g")
                .data(series)
                .enter()
                .append('g')
                .attr('id', 'g-rect')
                .attr("fill", d => color(d.key))
                .selectAll("rect")
                .data(d => d)
                .enter()
                .append('rect')
                .attr('class', 'rect')
                .attr("x", (d, i) => x(d.data.month))
                .attr("y", d => y(d[1]))
                .attr("height", d => y(d[0]) - y(d[1]))
                .attr("width", x.bandwidth())

            // create legends
            svg.selectAll('.legend')
                .data(legends)
                .enter()
                .append('rect')
                .attr('class', 'legend-bar')
                .attr('x', inner_width - 150)
                .attr('y', (d, i) => i * 20)
                .attr('height', 20)
                .attr('width', 50)
                .attr('fill', d => color(d));

            svg.selectAll('.text')
                .data(legends)
                .enter()
                .append('text')
                .attr('class', 'legend-text')
                .attr('x', inner_width - 90)
                .attr('y', (d, i) => i * 20)
                .style('alignment-baseline', 'hanging')
                .style('text-anchor', 'start')
                .style('fill', '#fee0d2')
                .style('font-size', '15')
                .text(d => d);
                
            resize();
            d3.select(window).on('resize', resize);
            
            function resize() {
                var new_width = parseInt(d3.select('#chart2').style('width')) - margin.left - margin.right;
                var new_height = parseInt(d3.select('#chart2').style('height')) - margin.top - margin.bottom;
                svg.attr('width', new_width).attr('height', new_height);

                x.range([0, new_width]);
                y.range([new_height, 0]).nice();

                svg.selectAll('.legend-bar')
                    .attr('x', new_width - 150 * new_width / inner_width)
                    .attr('y', (d, i) => i * 20 * new_height / inner_height)
                    .attr('height', 20 * new_height / inner_height)
                    .attr('width',  50 * new_width / inner_width);

                svg.selectAll('.legend-text')
                    .attr('x', new_width + 10 - 100 * new_width / inner_width)
                    .attr('y', (d, i) => i * 20 * new_height / inner_height);
            
                if (new_width < 750) {
                    svg.selectAll('#g-circle')
                        .data(series)
                        .selectAll('.circle')
                        .data(d => d)
                        .attr("cx", d => x(d.data.month) + x.bandwidth() / 2)
                        .attr("cy", d => y(d[1]))
                        .attr("r", 5);
            
                    svg.selectAll('.line')
                        .data(data)
                        .attr('x1', d => x(d.month) + x.bandwidth() / 2)
                        .attr('y1', new_height)
                        .attr('x2', d => x(d.month) + x.bandwidth() / 2)
                        .attr('y2', d => y(d3.sum(legends.map(k => d[k]))));
            
                    svg.select('.x.axis').style('display', 'none');
                    svg.select('.y.axis').style('display', 'none');
                    svg.selectAll('.rect').style('display', 'none');
                    svg.selectAll('.circle').style('display', 'initial');
                    svg.selectAll('.line').style('display', 'initial');

                } else {
                    svg.selectAll("#g-rect")
                        .data(series)
                        .selectAll("rect")
                        .data(d => d)
                        .attr("x", d => x(d.data.month))
                        .attr("y", d => y(d[1]))
                        .attr("height", d => y(d[0]) - y(d[1]))
                        .attr("width", x.bandwidth());
            
                    svg.select('.x.axis')
                        .attr('transform', 'translate(0,' + new_height + ')')
                        .call(d3.axisBottom(x));
            
                    svg.select('.y.axis')
                        .call(d3.axisLeft(y));
            
                    svg.select('.x.axis').style('display', 'initial');
                    svg.select('.y.axis').style('display', 'initial');
                    svg.selectAll('.circle').style('display', 'none');
                    svg.selectAll('.line').style('display', 'none');
                    svg.selectAll('.rect').style('display', 'initial');
                }
            };  
        }
    },
    mounted: function () {        
        if (!this.$store.state.seasonalityData) {
            var month_name = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            
            d3.csv('seasonality.csv', function(d) {
                return {
                    month: month_name[+d.month - 1],
                    arson: +d.arson,
                    campfire: +d.campfire,
                    debris_burning: + d.debris_burning,
                    equipment_use: +d.equipment_use,
                    lightning: +d.lightning,
                    smoking: +d.smoking
                }
            }).then(data => {
                this.seasonalityData = data;      
                this.$store.commit('seasonalityData', this.seasonalityData);
                this.D3Responsive();
            });
        } else {
            this.seasonalityData = this.$store.state.seasonalityData;
            this.D3Responsive();
        }
    }
}
</script>