<template>
  <div class="home">
    <div>
      <img class="center-fit" src="fire_spark.jpg" alt="Home Background" />
    </div>

    <h1 class="first-txt" style="color: #fee0d2">
      Hotshot Crew 554 - US Wildfires Analysis
    </h1>
    <p class="third-txt" style="color: #fee0d2">Asumi Suguro | Luke Nelson | Kaile Huang | Po-Han Chen</p>
    <h3 class="second-txt" style="color: #fee0d2">
      "Wildfires are a result of temperature conditions, of soil moisture
      conditions; and, of course, something has to start it."
      <br />
      ~ John Holdren
    </h3>
    <h5 class="second-txt" style="color: #fee0d2">
      <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
      In this project, we utilize various visualizations to explore
      different dimensions of historic US wildfires.
      <!-- <br /> -->
      Through these visualizations, we deliver the argument that being proactive towards preventing fires is achievable, 
      and should be given just as much attention as is given to putting them out.
      <br /><br />
      *Please nevigate through the menu from left to right.
    </h5>
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: "Home",
};
</script>

<style scoped>
/* >>> .center-fit {
    max-width: 100%;
    max-height: 100vh;
    margin: auto;
} */

>>> img {
  padding: 0;
  display: block;
  margin: 0 auto;
  max-height: 100%;
  max-width: 100%;
}

>>> .first-txt {
  position: absolute;
  top: 20%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #fee0d2;
}

>>> .second-txt {
  position: absolute;
  top: 40%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #fee0d2;
  text-align: left;
}

>>> .third-txt {
  position: absolute;
  top: 29%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #fee0d2;
  text-align: left;
}
</style>
