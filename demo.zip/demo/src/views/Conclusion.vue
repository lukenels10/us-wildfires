<template>
  <div class="conclusion">
    <div>
      <img class="center-fit" src="fire_spark.jpg" alt="Home Background" />
    </div>
    <h1 class="first-txt" style="color: #fee0d2">Conclusion</h1>
    <h5 class="second-txt" style="color: #fee0d2">
      Wildfires in the United States have become more severe in terms of both
      count and size over the past few decades. And the responsive increase in
      funding for suppression alone has not been a sufficient fix or remedy. We
      recommend that more attention be placed on developing preventative
      measures specific to the regional and seasonal patterns we have just
      displayed. To learn more about our project, visit our project repository
      <a href="https://github.com/DSCI-554/project-hotshot-crew-554">here</a>.
    </h5>
  </div>
</template>

<script>
export default {
  name: "Conclusion",
};
</script>

<style scoped>
>>> a {
  color: #fc9272;
}
>>> img {
  padding: 0;
  display: block;
  margin: 0 auto;
  max-height: 100%;
  max-width: 100%;
}

>>> .first-txt {
  position: absolute;
  top: 25%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

>>> .second-txt {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  text-align: left;
}
</style>
