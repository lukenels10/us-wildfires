<template>
  <div class="d3Map" :style="{ 'backgroundColor': 'black'}">
    <b-container>
      <p align="left">
        The map on the left hand side plotted all the wildfires from 1992-1996 in the US.
        Whereas the other map shows fires from 2011-2015.
        The larger the circle is, the larger the fire was.
        You can click on one of the six main causes of wildfires down below to filter the data.
        Click "Reset" to show all the wildfires as default.
      </p>
    </b-container>
      <div align="center">
        <svg width="925" height="20" id="legend"></svg>
      </div>
      <div class="container">
        <div class="col svg-container">
          <svg id="chart1" align ="right"></svg>
        </div>
        <div class="col svg-container">
          <svg id="chart2" align = "left"></svg>
        </div>
      </div>
      <h3>The Spread of Wildfires in the US</h3>
      <b-container>
     
      <p align="left">
        Comparing two d3 maps, we could see that wildfires has become more prevalent in the US.
        Specifically, there's a trend that the fires started "invading" the Midwest. 
        Additionally, the severity and numbers of wildfires also increased on the West coast and in the Southeast.
      </p>
      </b-container>
      <b-container>
      <p align="left">
        The pattern of increased numbers and severity can also be seen when filtering data by the cause of fires.
        This indicates that both human activities and natural factors have contributed to the trend.
      </p>
      </b-container>
      <b-container>
      <p align="left">
        Every year in the US, millions of dollars are spent to suppress the wildfires.
        Some notoriously severe ones have even costed lives of our brave fighters.
        However, suppression are not optimal when preventional methods might be more cost-efficient and safe.
        So, how does the government's effort to put down the fires work out so far?
      </p>
      </b-container>
      
  </div>
  
</template>

<script>

import * as d3 from 'd3';
import VueSlideBar from 'vue-slide-bar';

export default {
  name: 'd3Map',
  data: function () {
    return {
      D3MapData: null,
    }
  },
  methods: {
    D3Map() {
      var us = this.D3MapData[0];
      var data = this.D3MapData[1];
      let year_array1 = Array.from(Array(5),(x,index)=>index+1992)
      let year_array2 = Array.from(Array(5),(x,index)=>index+2011)
      console.log(year_array1)
      //introduce color scale
      var cause_array = ["Debris Burning","Lightning","Equipment Use","Smoking" ,"Arson","Campfire"]
      var color_array = ["#BEBADA","#FFFFB3","#80B1D3","#8DD3C7","#FB8072","#FDB462"]
      var color_scale = d3.scaleOrdinal()
                      .domain(cause_array)
                      .range(color_array)
      var legend_array = ["Debris","Lightning","Equipment","Smoking" ,"Arson","Campfire"]
      var legend = d3.select('#legend')
                      .selectAll('circle')
                      .data(legend_array)
                      .enter()
                      .append('circle')
                      .attr('r',10)
                      .attr('cx',(d,i)=>10+i*140)
                      .attr('cy',10)
                      .attr('fill',(d,i)=>color_scale(cause_array[i ]))
                      .attr('fill-opacity',0.8)
                      .attr('class',d=>d)
                      .on('click',function(){
                        //reset
                        d3.select("#legend")
                            .selectAll("circle")
                            .attr('fill-opacity',0.5)
                        d3.select('#legend')
                          .selectAll('text')
                          .attr('font-weight','normal')
                        d3.select('#chart1')
                            .selectAll('circle')
                            .attr('fill-opacity',0)
                            .attr('stroke-width',0)
                        d3.select('#chart2')
                            .selectAll('circle')
                            .attr('fill-opacity',0)
                            .attr('stroke-width',0)
                        //emphasize
                        d3.select(this)
                            .attr('fill-opacity',0.8);
                        d3.select('#legend')
                            .select('text.'+String(d3.select(this).attr('class')))
                            .attr('font-weight','bolder')
                        d3.select("#chart1")
                            .selectAll('circle.'+String(d3.select(this).attr('class')))
                            .filter('.year_first')
                            .attr('fill-opacity',0.5)
                            .attr('stroke-width',0.5);
                        d3.select("#chart2")
                            .selectAll('circle.'+String(d3.select(this).attr('class')))
                            .filter('.year_second')
                            .attr('fill-opacity',0.5)
                            .attr('stroke-width',0.5);
                      })
                      // .on('mouseout',function(){
                      //   d3.select(this)
                      //       .attr('fill-opacity',0.5);
                      //   d3.selectAll('circle.'+String(d3.select(this).attr('class')))
                      //       .attr('fill-opacity',0.5);
                      // })
      d3.select("#legend")
          .selectAll("text")
          .data(cause_array)
          .enter()
          .append('text')
          .text(d=>d)
          .attr('x',(d,i)=>25+i*140)
          .attr('y',10)
          .attr('fill','#fee0d2')
          .attr('text-anchor','start')
          //.attr('alignment-baseline','middle')
          .style("dominant-baseline","central")
          .attr('class',(d,i)=>legend_array[i])
          .on('click',function(){
                        //reset
                        d3.select("#legend")
                            .selectAll("circle")
                            .attr('fill-opacity',0.5)
                        d3.select('#legend')
                          .selectAll('text')
                          .attr('font-weight','normal')
                        d3.select('#chart1')
                            .selectAll('circle')
                            .attr('fill-opacity',0)
                            .attr('stroke-width',0)
                        d3.select('#chart2')
                            .selectAll('circle')
                            .attr('fill-opacity',0)
                            .attr('stroke-width',0)
                        //emphasize
                        d3.select(this)
                            .attr('font-weight','bolder');
                        d3.select('#legend')
                            .select('circle.'+String(d3.select(this).attr('class')))
                            .attr('fill-opacity',0.8);
                        d3.select("#chart1")
                            .selectAll('circle.'+String(d3.select(this).attr('class')))
                            .filter('.year_first')
                            .attr('fill-opacity',0.5)
                            .attr('stroke-width',0.5);
                        d3.select("#chart2")
                            .selectAll('circle.'+String(d3.select(this).attr('class')))
                            .filter('.year_second')
                            .attr('fill-opacity',0.5)
                            .attr('stroke-width',0.5);
                      })
      //reset button 
      d3.select("#legend")
          .append('circle')
          .attr('r',10)
          .attr('cx',850)
          .attr('cy',10)
          .attr('fill','white')
          .attr('fill-opacity',0.5)
          .on("click",function(){
            //reset
            d3.select("#legend")
                .selectAll("circle")
                .attr('fill-opacity',0.8)
            d3.select('#legend')
              .selectAll('text')
              .attr('font-weight','normal')
            d3.select("#chart1")
              .selectAll('circle')
              .filter('.year_first')
              .attr('fill-opacity',0.5)
              .attr('stroke-width',0.5);
            d3.select("#chart2")
                .selectAll('circle')
                .filter('.year_second')
                .attr('fill-opacity',0.5)
                .attr('stroke-width',0.5);
          });
      d3.select('#legend')
          .append('text')
          .text('Reset')
          .attr('x',(d,i)=>865)
          .attr('y',10)
          .attr('fill','#fee0d2')
          .attr('text-anchor','start')
          //.attr('alignment-baseline','middle') //does not work in deployment
          .style("dominant-baseline","central")
          .attr('fill','#fee0d2')
          .on("click",function(){
            //reset
            d3.select("#legend")
                .selectAll("circle")
                .attr('fill-opacity',0.8)
            d3.select('#legend')
              .selectAll('text')
              .attr('font-weight','normal')
            d3.select("#chart1")
              .selectAll('circle.year_first')
              .attr('fill-opacity',0.5)
              .attr('stroke-width',0.5);
            d3.select("#chart2")
                .selectAll('circle.year_second')
                .attr('fill-opacity',0.5)
                .attr('stroke-width',0.5);
          });

      // var size_array
      // size_array = data.features.map(function(item){
      //   return Number(item.properties.FIRE_SIZE)
      // })
      // console.log(d3.quantile(size_array,0.975))

      //introduce radius scale
      var radius_scale = d3.scaleSqrt()
                              .domain([0,19322.1])
                              .range([2,7])

      //initializing svg
      var svg = d3.select('#chart1')
            .style('background-color','none')
            .attr("preserveAspectRatio", "xMinYMin meet")
            .attr("viewBox", "0 0 400 300")
            // Class to make it responsive.
            .classed("svg-content-responsive", true);
      

      var projection = d3.geoAlbersUsa()
          .fitSize([400, 300], us);
          
      var path = d3.geoPath().projection(projection);

      var graticule = d3.geoGraticule()  //🚧  explain: Constructs a geometry generator for creating graticules: a uniform grid of meridians and parallels for showing projection distortion and set the major and minor steps
              .step([10, 10]);
              
      // svg.append('path')
      //     .datum(graticule)  //🚧  explain: associate path tag with graticule
      //     .attr('class', 'graticule')
      //     .attr('d', path)

      svg.selectAll('.states')
        .data(us.features)  //🚧  explain: associate path with each feature in json
        .enter()
        .append('path')
        .attr('fill', d => 'grey')  //🚧  explain: fill each state with white
        //.attr('fill', d => d.id == '06' ? '#FFCC00' : 'white')  //🚧  try and explain: fill California with yellow
        .attr('class', 'states')
        .attr('d', path);

      //buttons
      
      // svg.append('rect')
      //     .attr('fill','white')
      //     .attr('width',100)
      //     .attr('height',50)
      //     .on('click',next_cause)
      //     .attr('y',0)

      

      var cur_year = 1992
      svg.append('text')
            .attr('class','year')
            .attr('x',200)
            .attr('y',30)
            .attr('fill','#fc9272')
            .attr('font-size',30)
            .text('1992-1996')

      console.log(projection([-85.41, 30.43 ]))
      svg.append('g')
        .attr('stroke', '#fff')
        .selectAll('circle')
        .data(data.features)
        .enter()
        .append('circle')
        .attr('cx', d=>projection(d.geometry.coordinates)?projection(d.geometry.coordinates)[0]:1000)
        .attr('cy', d=>projection(d.geometry.coordinates)?projection(d.geometry.coordinates)[1]:1000)
        .attr('r', d=>radius_scale(d.properties.FIRE_SIZE))
        .attr('class',d=>cause_array.includes(d.properties.STAT_CAUSE_DESCR)?(year_array1.includes(d.properties.FIRE_YEAR)?'year_first'+' '+d.properties.STAT_CAUSE_DESCR.toString():'year_other'+' '+d.properties.STAT_CAUSE_DESCR.toString()):'none')
        //.attr('class',d=>d.properties.STAT_CAUSE_DESCR)
        //(d.properties.STAT_CAUSE_DESCR==default_cause?0.5:0)
        .attr('fill-opacity', d=>year_array1.includes(d.properties.FIRE_YEAR)? (cause_array.includes(d.properties.STAT_CAUSE_DESCR)?0.5:0):0)
        .attr('stroke-width', d=>year_array1.includes(d.properties.FIRE_YEAR)? (cause_array.includes(d.properties.STAT_CAUSE_DESCR)?0.5:0):0)
        .attr('fill',d=>cause_array.includes(d.properties.STAT_CAUSE_DESCR)?color_scale(d.properties.STAT_CAUSE_DESCR):'white')

      //create legend
      // svg.append('g')
      //     .selectAll('text')
      //     .data(cause_array)
      //     .enter()
      //     .append('text')
      //     .text(d=>d)
      //     .attr('x',300)
      //     .attr('y',30)
      //     .attr("fill","brown")
      //     .attr("class",d=>d)
      //     .attr("opacity",d=>d=="Debris Burning"?1:0)
      //     .attr('font-size',30)
      ///////////////
      //chart2
      var svg2 = d3.select('#chart2')
            .style('background-color','none')
            .attr("preserveAspectRatio", "xMinYMin meet")
            .attr("viewBox", "0 0 400 300")
            // Class to make it responsive.
            .classed("svg-content-responsive", true)

      // svg2.append('path')
      //     .datum(graticule)  //🚧  explain: associate path tag with graticule
      //     .attr('class', 'graticule')
      //     .attr('d', path)

      svg2.selectAll('.states')
        .data(us.features)  //🚧  explain: associate path with each feature in json
        .enter()
        .append('path')
        .attr('fill', d => 'grey')  //🚧  explain: fill each state with white
        //.attr('fill', d => d.id == '06' ? '#FFCC00' : 'white')  //🚧  try and explain: fill California with yellow
        .attr('class', 'states')
        .attr('d', path);

      svg2.append('text')
            .attr('class','year')
            .attr('x',200)
            .attr('y',30)
            .attr('fill','#fc9272')
            .attr('font-size',30)
            .text('2011-2015')

      svg2.append('g')
        .attr('stroke', '#fff')
        .selectAll('circle')
        .data(data.features)
        .enter()
        .append('circle')
        .attr('cx', d=>projection(d.geometry.coordinates)?projection(d.geometry.coordinates)[0]:1000)
        .attr('cy', d=>projection(d.geometry.coordinates)?projection(d.geometry.coordinates)[1]:1000)
        .attr('r', d=>radius_scale(d.properties.FIRE_SIZE))
        .attr('class',d=>cause_array.includes(d.properties.STAT_CAUSE_DESCR)?(year_array2.includes(d.properties.FIRE_YEAR)?'year_second'+' '+d.properties.STAT_CAUSE_DESCR.toString():'year_other'+' '+d.properties.STAT_CAUSE_DESCR.toString()):'none')
        //.attr('class',d=>d.properties.STAT_CAUSE_DESCR)
        .attr('fill-opacity', d=>year_array2.includes(d.properties.FIRE_YEAR)? (cause_array.includes(d.properties.STAT_CAUSE_DESCR)?0.5:0):0)
        .attr('stroke-width', d=>year_array2.includes(d.properties.FIRE_YEAR)? (cause_array.includes(d.properties.STAT_CAUSE_DESCR)?0.5:0):0)
        .attr('fill',d=>cause_array.includes(d.properties.STAT_CAUSE_DESCR)?color_scale(d.properties.STAT_CAUSE_DESCR):'white')
        // .on("mouseover",function(){
        //   d3.selectAll('.'+String(d3.select(this).attr('class')).split(" ")[0]+',.'+String(d3.select(this).attr('class')).split(" ")[1])
        //       .attr('fill-opacity',1)
        //       .attr('stroke-width',1)
        // })
        // .on("mouseout",function(){
        //   d3.selectAll('.'+String(d3.select(this).attr('class')).split(" ")[0]+',.'+String(d3.select(this).attr('class')).split(" ")[1])
        //       .attr('fill-opacity', 0.5)
        //       .attr('stroke-width', 0.5)
        // })

      var cur_legend = 0
      
      function next_cause (d,i){
          d3.select('text.'+legend_array[cur_legend])
                .attr("opacity",0)
     
          d3.selectAll('circle')
              .attr('fill-opacity',0)
              .attr('stroke-width',0)

          cur_legend==5?cur_legend =0:cur_legend = cur_legend+1;

          
          d3.selectAll('circle.'+legend_array[cur_legend])
              .filter('.year_'+cur_year.toString())
              .attr('fill-opacity',0.5)
              .attr('stroke-width',0.5)
          d3.select('text.'+legend_array[cur_legend])
              .attr("opacity",1)
      }
    ////end of method
    }      
  },
  //////////
  //mounted
  mounted: function () {
    console.log('mounted');

    
    if (!this.$store.state.vueD3MapData) {
      var promises = [];
      var files = ['us.json', 'd3map_new.json'];
      files.forEach(url => promises.push(d3.json(url)));

      Promise.all(promises).then(data => {
        this.D3MapData = data;      
        this.$store.commit('vueD3MapData', this.D3MapData);

        //plot the chart
        this.D3Map();
        });
    } else {
      this.D3MapData = this.$store.state.vueD3MapData;
 
      //plot the chart
      this.D3Map();
    }
  }
}
</script>

<!-- "scoped" attribute limits CSS to this component only -->
<style scoped>
>>> text.label {  /* need to add >>> to gets passed to d3 because vue creates new mapping */
  text-anchor: end;
  alignment-baseline: middle;
  font-size: 12px;
  fill: black;
}

>>> text.value {
  font-family: 'Courier New', Courier, monospace;
  font-weight: bolder;
  font-size: 12px;
  text-anchor: end;
  alignment-baseline: middle;
  fill: #eee;
}

>>> rect.bar {
  text-align: right;  /* pull value text to the end of the bar */
  vertical-align: middle;  /* align value text with middle of the bar */
  fill:#7abcff;
  height: 20px;  /* bar height, this can stay fixed */
}

.title {
  margin-bottom: 0px;
  font-size: 12px;
}

>>> path.graticule {
    fill: none;
    stroke: grey;
    stroke-width: .3px;
    stroke-opacity: 0.8;
  }

>>> path.states {
    stroke: black;
    stroke-width: .3px;
  }
>>> .container {
  display:flex;
}

>>> .svg-container {
  display: inline-block;
  position: relative;
  width: 100%;
  padding-bottom: 37%; /* aspect ratio */
  vertical-align: top;
  overflow: hidden;
}
>>> .svg-content-responsive {
  display: inline-block;
  position: absolute;
  top: 10px;
  left: 0;
}

>>> img {
    padding: 0;
    display: block;
    margin: 0 auto;
    max-height: 100%;
    max-width: 100%;
}
</style>
