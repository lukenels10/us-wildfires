<template>
  <div class="d3Interaction">
    <br />
    <b-container>
      <p class="font-italic" aligh="left">
        According to the Congressional Research Service, “Suppression is the
        work associated with wildfire response and includes postfire emergency
        stabilization measures….Fuel reduction is a wildfire prevention activity
        intended to mitigate the risk of catastrophic fires.”
      </p>
    </b-container>
    <br />
    <div id='suppVSred' >
      <div class="w-50 d-inline-block">
        
    <h3>Suppression vs Fuel Reduction Funding</h3>
        <br />    <br />
        <div id="bar_container" class="h-100 w-100 d-inline-block">
          <svg id="bar"></svg>
        </div>
      </div>
      <div class="w-25 d-inline-block  align-top">
        <div id="commands_bar" align="center" class="mt-5 w-100 d-block">
          <b-button id="start" type="button" variant="secondary ml-2">
            Start Animation
          </b-button>
          <b-button id="reset" type="button" variant="secondary ml-2">
            Reset
          </b-button>
        </div><br />
        <p class="align-top text-left">
          In this chart, the federal funding in suppression and fuel reduction
          in millions are compared to the number of fires from 1999 to 2015. Up
          till 2010, the fire counts remained under 40,000. However, a
          significant increase in fire counts was observed starting from 2011.
          Looking at the federal fundings, the amount allotted to suppression
          has increased with the fire counts. However, funding in fuel reduction
          remained around the same. This brings to question the effectiveness of
          increasing suppression funding.
        </p>
      </div>
    </div><br />
      <br />
      <div id='suppVStime'>
        <div class="w-50 d-inline-block">
      <h3>Suppression Funding vs Contained Time of Fire</h3>    <br />    <br />
          <!-- <div id='buttons' align="center" class="w-100 d-block">
              <b-button id="all" type="button" variant="secondary ml-2">
                All
              </b-button>
              <b-button id="bin1" type="button" variant="secondary ml-2">
                Remove Outlier
              </b-button>
            </div> -->
          <div id="scatter_container" class="h-100 w-100 d-inline-block">
            <div id="scatter" class="h-100 w-100 d-inline-block"></div>            
          </div>
          </div>
          <div class="w-25 mt-5 d-inline-block align-top">
            <p class="align-middle text-left h-100">
              Therefore, we examine the impact of increasing suppression funding
              on the average contained time of fire of the year. When the two
              variables are plotted against each other, an outlier stands out
              for 2014, in which the U.S. experienced a spike in the number of
              fires. Removing the 2014 record shows that there is no direct
              correlation between suppression funding and contained time. This
              suggests that increase in suppression funding does not have a
              direct impact on the contained time of fire. Hover over each dot to see the year it represents.
            </p>
          </div>
      </div>
      <br />
    <!-- <div>
      <img class="center-fit" src="fuego.jpg" alt="fuego" />
    </div> -->
  </div>

</template>

<script>
import * as d3 from "d3";

export default {
  name: "d3Interaction",
  data: function () {
    return {
      D3InteractionData: null,
    };
  },
  methods: {
    D3Animation2() {
      var funding = this.D3Animation2Data[0];
      var fire_count = this.D3Animation2Data[1];
      // set the dimensions and margins of the graph
      var margin = { top: 20, right: 55, bottom: 30, left: 80 },
        width = 800 - margin.left - margin.right,
        height = 300 - margin.top - margin.bottom;

      // filtered data by years
      var funding_2015 = funding.filter((d) => d.year <= 2015);

      // parse the year / time
      var parseTime = d3.timeParse("%Y");

      var formatValue = d3.format(".1s");

      // set the ranges
      var x = d3.scaleTime().range([0 + 10, width - 10]);
      var y0 = d3.scaleLinear().range([height, 0]);
      var y1 = d3.scaleLinear().range([height, 0]);

      // define the 1st line - suppression
      var suppLine = d3
        .line()
        .x(function (d) {
          return x(parseTime(d.year));
        })
        .y(function (d) {
          return y0(d.supp);
        });

      // define the 2nd line - fuel reduction
      var fuelLine = d3
        .line()
        .x(function (d) {
          return x(parseTime(d.year));
        })
        .y(function (d) {
          return y0(d.red);
        });

      // append the svg object
      var svg = d3
        .select("#bar")
        .attr("viewBox", "0 0 830 330")
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

      // Scale the range of the data
      x.domain(
        d3.extent(fire_count, function (d) {
          return parseTime(d.year);
        })
      );
      y0.domain([
        0,
        d3.max(fire_count, function (d) {
          return d.supp;
        }),
      ]);

      // Add the X Axis
      var xAxis = d3.axisBottom().scale(x).ticks(22);

      svg
        .append("g")
        .attr("transform", "translate(0," + height + ")")
        .attr("class", "axis")
        .call(xAxis);

      // Add the LEFT y-Axis
      var y0Axis = d3.axisLeft().scale(y0).ticks(5);

      svg.append("g").attr("class", "axis").call(y0Axis);

      var x1 = d3
        .scaleBand()
        .domain(fire_count.map((d) => parseTime(d.year)))
        .range([0, width])
        .paddingInner(0.4)
        .paddingOuter(0);

      y1.domain([
        d3.min(fire_count, (d) => d.count),
        d3.max(fire_count, (d) => d.count),
      ]).nice();

      var y1Axis = d3
        .axisRight()
        .ticks(5)
        .scale(y1)
        .tickFormat((d) => formatValue(d).replace("G", "B"));

      // Add the RIGHT y-Axis
      svg
        .append("g")
        .attr("class", "axis")
        .attr("transform", "translate( " + width + ", 0 )")
        .call(y1Axis);

      // Plotting bar chart
      svg
        .selectAll(".bar")
        .data(fire_count, (d) => parseTime(d.year))
        .enter()
        .append("rect")
        .attr("class", "bar")
        .attr("x", (d) => x1(parseTime(d.year)))
        .attr("y", (d) => y1(d.count))
        .attr("width", x1.bandwidth())
        .attr("height", (d) => height - y1(d.count));

      // Start Animation2 on Click
      d3.select("#start").on("click", function () {
        // Add the suppLine path.
        var path1 = svg
          .append("path")
          .data([fire_count])
          .attr("fill", "none")
          .attr("class", "line")
          .attr("d", suppLine)
          .attr("stroke", "#ff7f00");

        // Add the fuelLine path.
        var path2 = svg
          .append("path")
          .data([fire_count])
          .attr("fill", "none")
          .attr("class", "line")
          .style("stroke", "#377eb8")
          .attr("d", fuelLine);

        // Variable to Hold Total Length
        var totalLength = path1.node().getTotalLength();
        // Set Properties of Dash Array and Dash Offset and initiate Transition
        path1
          .attr("stroke-dasharray", totalLength + " " + totalLength)
          .attr("stroke-dashoffset", totalLength)
          .transition()
          .duration(4000)
          .ease(d3.easeLinear)
          .attr("stroke-dashoffset", 0);

        // Variable to Hold Total Length
        var totalLength = path2.node().getTotalLength();

        // Set Properties of Dash Array and Dash Offset and initiate Transition
        path2
          .attr("stroke-dasharray", totalLength + " " + totalLength)
          .attr("stroke-dashoffset", totalLength)
          .transition()
          .duration(4000)
          .ease(d3.easeLinear)
          .attr("stroke-dashoffset", 0); // Set final value of dash-offset for transition
      });

      // Reset Animation2
      d3.select("#reset").on("click", function () {
        d3.selectAll(".line").remove();
      });

      // y Left label
      svg
        .append("text")
        .attr("x", -100)
        .attr("y", -65)
        .attr("transform", "rotate(-90)")
        .attr("class", "label")
        .append("tspan")
        .text("Funding (million)");

      // y Right label
      svg
        .append("text")
        .attr("x", 100)
        .attr("y", -width - 55)
        .attr("transform", "rotate(90)")
        .attr("class", "label")
        .append("tspan")
        .text("Fire Count");

      // // Title
      // svg
      //   .append("text")
      //   .attr("class", "title")
      //   .text("Suppression vs. Fuel Reduction Funding")
      //   .attr("x", width / 2)
      //   .attr("y", -30);

      // Legend
      svg
        .append("text")
        .attr("x", 80)
        .attr("y", 25)
        .attr("class", "legend")
        .append("tspan")
        .text("Suppression Funding");

      svg
        .append("text")
        .attr("x", 80)
        .attr("y", 45)
        .attr("class", "legend")
        .append("tspan")
        .text("Fuel Reduction Funding");

      svg
        .append("text")
        .attr("x", 80)
        .attr("y", 65)
        .attr("class", "legend")
        .append("tspan")
        .text("Fire Count");

      svg
        .append("line")
        .style("stroke", "#ff7f00")
        .attr("x1", 60)
        .attr("y1", 20)
        .attr("x2", 73)
        .attr("y2", 20)
        .attr("class", "legend_line");

      svg
        .append("line")
        .style("stroke", "#377eb8")
        .attr("x1", 60)
        .attr("y1", 40)
        .attr("x2", 73)
        .attr("y2", 40)
        .attr("class", "legend_line");

      svg
        .append("rect")
        .attr("class", "bar")
        .attr("x", 60.5)
        .attr("y", 55.0)
        .attr("width", 12)
        .attr("height", 12);

      svg
        .append("line")
        .style("stroke", "black")
        .attr("x1", 0)
        .attr("y1", height + 0.5)
        .attr("x2", 10)
        .attr("y2", height + 0.5)
        .attr("stroke-width", 0.5);

      svg
        .append("line")
        .style("stroke", "black")
        .attr("x1", width - 20)
        .attr("y1", height + 0.5)
        .attr("x2", width)
        .attr("y2", height + 0.5)
        .attr("stroke-width", 0.5);
    },
    D3Interaction() {
      var data = this.D3InteractionData;
      var margin = { top: 20, left: 70, bottom: 50, right: 60 },
        width = 800 - margin.left - margin.right,
        height = 300 - margin.top - margin.bottom;

      var svg = d3
        .select("#scatter")
        .append("svg")
        .attr("viewBox", "0 0 830 330")
        // .attr("width", "100%")
        // .attr("height", "100%")

        .append("g")
        .attr(
          "transform",
          "translate(" + margin.left + ", " + margin.top + ")"
        );
      var x = d3.scaleLinear();
      var yLeft = d3.scaleLinear();
      var yRight = d3.scaleLinear();
      var delay = function (d, i) {
        return i * 50;
      };
      var all, no_outlier, bin1;
      var current, filterMode;
      all = data;

      // filtered data by years
      no_outlier = all.filter((d) => d.year != 2014);

      // initial plot
      filter("#all");
      toggleFilter("#all");
      draw();

      //filter event handlers
      d3.select("#all").on("click", () => {
        filter("#all");
        toggleFilter("#all");
        redraw();
      });
      d3.select("#bin1").on("click", () => {
        filter("#bin1");
        toggleFilter("#bin1");
        redraw();
      });
      d3.select("input").on("change", () => {
        redraw();
      });

      function filter(mode) {
        if (mode === "#all") {
          current = JSON.parse(JSON.stringify(all));
        } else if (mode === "#bin1") {
          current = JSON.parse(JSON.stringify(no_outlier));
          filterMode = mode;
        }
      }

      // highlight buttons with class 'filter'
      function toggleFilter(id) {
        // d3.selectAll(".btn").style("background-color", "#eee");
        // d3.select(id).style("background-color", "lightpink");
      }

      function redraw() {
        //update scale
        x.domain([
          d3.min(current, (d) => d.supp),
          d3.max(current, (d) => d.supp),
        ]);
        yLeft.domain([0, d3.max(current, (d) => d.avg_contained_time)]).nice();
        ////////////////////////////////
        // DATA JOIN FOR BARS.
        var time = svg.selectAll(".time").data(current, (d) => d.supp);
        // UPDATE.
        time
          .transition()
          .duration(750)
          .delay(delay)
          .attr("cx", (d) => x(d.supp))
          .attr("cy", (d) => yLeft(d.avg_contained_time))
          .attr("r", 5);
        // ENTER.
        time
          .enter()
          .append("circle")
          .attr("cx", (d) => x(d.supp))
          .attr("cy", (d) => yLeft(d.avg_contained_time))
          .attr("r", 5)
          .style("opacity", 0)
          .transition()
          .duration(750)
          .attr("class", "time")
          .attr("cx", (d) => x(d.supp))
          .attr("cy", (d) => yLeft(d.avg_contained_time))
          .attr("r", 5)
          .attr("fill", "#ff7f00")
          .style("opacity", 1);
        // EXIT.
        time.exit().transition().duration(750).style("opacity", 0).remove();
        // X Axis
        var xAxis = svg.select("#xaxis_scatter");
        var xBottomAxis = d3.axisBottom().scale(x).ticks(10, "d").tickSize(5);
        xAxis.transition().duration(750).delay(delay).call(xBottomAxis);
        // Y Axis LEFT
        var yLeftAxis = d3.axisLeft().scale(yLeft).ticks(5, "d");
        var yaxis = svg.select("#yaxis_scatter");
        // UPDATE.
        yaxis.transition().duration(750).delay(delay).call(yLeftAxis);
        // ENTER.
        yaxis
          .enter()
          .call(yLeftAxis)
          .style("opacity", 0)
          .transition()
          .duration(1000)
          .call(yLeftAxis)
          .style("opacity", 1);
        // EXIT.
        yaxis.exit().transition().duration(750).style("opacity", 0).remove();
      }

      function transition() {
        var transition = svg.transition().duration(750);
        transition
          .selectAll(".time")
          .delay(delay)
          .attr("x", (d) => x(d.supp));
        transition
          .selectAll(".cause")
          .delay(delay)
          .attr("y", (d) => x(d.supp));
      }

      function draw() {
        x.domain([
          d3.min(current, (d) => d.supp),
          d3.max(current, (d) => d.supp),
        ]).range([0, width]);
        yLeft
          .domain([0, d3.max(current, (d) => d.avg_contained_time)])
          .nice()
          .range([height, 0]);
        svg
          .selectAll(".circle")
          .data(current, (d) => d.supp)
          .enter()
          .append("circle")
          .attr("class", "time")
          .attr("opacity", 1)
          .attr("cx", (d) => x(d.supp))
          .attr("cy", (d) => yLeft(d.avg_contained_time))
          .attr("r", 6)
          .attr("fill", "#FFB13C")
          .attr('stroke', 'white')
          .on("mouseover", function () {
            d3.select(this)
            .attr("fill", "#E64F4F")
            .attr('r', 9);            
          })
          .on("mouseout", function () {
            d3.select(this).attr("fill", "#FFB13C")
            .attr('r', 6);
          })
          .append("title")
          .text(function (d) {
            return "Year: " + d.year;
          });

        // X Axis
        var xAxis;
        xAxis = d3.axisBottom().scale(x).ticks(10, "d").tickSize(5);
        svg
          .append("g")
          .attr("class", "axis")
          .attr("id", "xaxis_scatter")
          .attr("transform", "translate(0," + height + ")")
          .call(xAxis);

        // X label
        svg
          .append("text")
          .attr("x", width / 2)
          .attr("y", height + 40)
          .attr("class", "label")
          .append("tspan")
          .text("Suppression Funding (million)");
        // Y Axis LEFT
        var yLeftAxis = d3.axisLeft().scale(yLeft).ticks(5, "d");
        svg
          .append("g")
          .attr("class", "axis")
          .attr("id", "yaxis_scatter")
          .call(yLeftAxis);
        // Y label
        svg
          .append("text")
          .attr("x", -100)
          .attr("y", -50)
          .attr("class", "label")
          .attr("transform", "rotate(-90)")
          .append("tspan")
          .text("Avg Contained Time (hour)");

        // // Title
        // svg
        //   .append("text")
        //   .attr("class", "title")
        //   .text("Suppression Funding vs Contained Time of Fire")
        //   .attr("x", width / 2)
        //   .attr("y", -30);
      }
    },
  },
  mounted: function () {
    console.log("mounted");

    if (!this.$store.state.vueD3InteractionData) {
      d3.json("1999_2015.json").then((data) => {
        this.D3InteractionData = data;
        this.$store.commit("vueD3InteractionData", this.D3InteractionData);

        this.D3Interaction();
      });
    } else {
      this.D3InteractionData = this.$store.state.vueD3InteractionData;
      this.D3Interaction();
    }
    if (!this.$store.state.vueD3Animation2Data) {
      var promises = [];
      var files = ["funding.json", "1999_2015.json"];
      files.forEach((url) => promises.push(d3.json(url)));

      Promise.all(promises).then((data) => {
        this.D3Animation2Data = data;
        this.$store.commit("vueD3Animation2Data", this.D3Animation2Data);
        //plot the chart
        this.D3Animation2();
      });
    } else {
      this.D3Animation2Data = this.$store.state.vueD3Animation2Data;

      //plot the chart
      this.D3Animation2();
    }
  },
};
</script>

<!-- "scoped" attribute limits CSS to this component only -->
<style scoped>
>>> .bar {
  fill: #984ea3;
  opacity: 0.8;
}
>>> .axis path {
  position: absolute;
  stroke: #fee0d2;
  stroke-width: 1px;
}
>>> .axis line {
  fill: none;
  stroke: #fee0d2;
  shape-rendering: crispEdges;
}
>>> .axis text {
  fill: #fee0d2;
  font-size: 1.4em;
}
>>> text {
  font-family: "Raleway", sans-serif;
  font-size: 1.4em;
}
>>> .title {
  text-anchor: middle;
  font-size: 1.6em;
  fill: #fee0d2;
}
>>> svg {
  display: block;
  margin: auto;
  background-color: black;
}
>>> text.xlabel {
  text-anchor: middle;
}
>>> text.ylabel {
  text-anchor: middle;
  alignment-baseline: central;
}
>>> .label tspan {
  alignment-baseline: central;
  text-anchor: middle;
  font-size: 0.7em;
  fill: #fee0d2;
}
>>> .filter {
  border-radius: 3px;
  background-color: #eee;
  padding: 5px;
  margin: 5px;
  color: #fee0d2;
  text-align: left;
  display: inline-block;
  cursor: default;
}
>>> .line {
  fill: none;
  stroke-width: 3px;
}
>>> .legend_line {
  fill: none;
  stroke-width: 3px;
}
>>> .legend tspan {
  fill: #fee0d2;
  font-size: 0.7em;
}

</style>
