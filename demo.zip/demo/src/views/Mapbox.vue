<template>
    <div>
        <!-- <MglMap
            :accessToken="accessToken"
            :mapStyle.sync="mapStyle"
            @load="onMapLoad">
            <MglGeojsonLayer
                :sourceId="drought_source"
                :source="geoJsonSource"
                layerId="state-drought"
                :layer="geoJsonlayer"
            />
        </MglMap> -->
        <div id="map" viewbox="0 0 600 400"></div>
        <div id="spacer" style="height:47px; width:100%; clear:both;">
            <b-container>
          	    <p id="descr" align="left">
		            The choropleth map shows the counts of wildfires with fire size larger than 100 in each state in the US from 1992 to 2015. The US is divided into four regions (the Midwest, the Northeast, the South and the West) and the regions are marked with white borders. We can see the severity of wildfires in the four regions and the fire causes by region are further explored. 
	              </p>
            </b-container>
        </div>
        <br>
        <br>        
            <!-- <div class="map-overlay-inner">
                <h3>US drought from 2000 to 2015</h3>
                <label id="year"></label>
                <input id="slider" type="range" min="0" max="15" step="1" value="0"/>
            </div> -->
        <div id="legend" class="legend">
            <h4>Count</h4>
            <div fill="dark"><span style="background-color: #bd0026"></span>10000</div>
            <div><span style="background-color: #fd8d3c"></span>1000</div>
            <div><span style="background-color: #fecc5c"></span>100</div>
            <div><span style="background-color: #ffffb2"></span>10</div>
            <div><span style="background-color: white"></span>0</div>
        </div>
    </div>
</template>

<script>
import * as d3 from 'd3';
import mapboxgl from "mapbox-gl";

export default {
    name: "Mapbox",
    mounted: function() {
        
        mapboxgl.accessToken = 'pk.eyJ1Ijoia2FpbGVodWFuZyIsImEiOiJja2dtcXA3ZHowMGtjMzFtb291OXJya2g2In0.n28GflBIsMk2W2h01m1JAQ';
        this.map = new mapboxgl.Map({
            container: "map",
            style: 'mapbox://styles/mapbox/dark-v10',
            center: [-98, 38.88],
            zoom: 3.5,
        });

        this.map.on('load', () => {
            this.map.addSource('drought_source', { 
                type: 'geojson', 
                data: 'us-fire-count-statewise.json'
            });

            this.map.addLayer({
                'id': 'state-drought',
                'source': 'drought_source',
                'type': 'fill',
                'paint': {
                    'fill-color': {
                        property: "count",
                        stops: [[0, '#fff'], [10, '#ffffb2'], [100, '#fecc5c'], [1000, '#fd8d3c'], [6000, '#bd0026']]
                    },
                    'fill-opacity': 0.6
                }
            });



            this.map.addLayer({
                'id': 'region',
                'source': {
                    type: 'geojson', 
                    data: 'regions.json'
                },
                'type': 'line',
                'paint': {
                    'line-color': 'white',
                    'line-width': 2
                    // 'line-color': '#89DDF7'
                }
            })

            // initialize
            // this.map.setFilter('state-drought', ['==', 'year', 2000]);
 
            // document.getElementById('slider').addEventListener('input', e => {
            //     var idx = parseInt(e.target.value, 10);
            //     var year = 2000 + idx;
            //     var filter = ['==', 'year', year];
            //     this.map.setFilter('state-drought', filter);

            //     // Set the label to the month
            //     document.getElementById('year').textContent = year;
            // });
        });
    }
}
</script>

<style scoped>
body { margin: 0; padding: 0; }
/* #map { position: absolute; left: 200px; height: 800px; width: 1200px} */
#map { position: absolute; top: 160px; bottom: 0; width: 100%; }

.legend {
    background-color:black;
    border-radius: 3px;
    bottom: 50px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
    font: 18px/20px 'Raleway', sans-serif;
    padding: 10px;
    position: absolute;
    right: 30px;
    z-index: 1;
}
 
.legend h4 {
    margin: 0 0 10px;
}
 
.legend div span {
    border-radius: 50%;
    display: inline-block;
    height: 10px;
    margin-right: 5px;
    width: 10px;
}
</style>