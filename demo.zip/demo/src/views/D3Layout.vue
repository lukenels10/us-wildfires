<template>
  <div class="d3Layout">
    <div class="answer">
      <div align="center">
		    <div id="spacer" style="height:47px; width:100%; clear:both;"></div>
          <div id="radarChart"></div>
            <div>
              <div id="spacer" style="height:47px; width:100%; clear:both;"></div>
          	    <p id="descr" align = "left">
		            This plot displays information related to the top 6 fire causes for all US regions over the entire 1992-2015 time period. It depicts the proportion each fire cause contributed to the total fire count, by region. For example: over the period, 50% of the fires in the West were caused by lightning, and 17% were caused by Equipment use. This plot shows the most common wildfire causes in the various regions of the US and shows that while there is overlap between certain regions, each region has specific causes that are more common: the West has strictly lightning to worry about; the Northeast could cut down on its wildfires significantly if it focused first on Arson and then on Debris burning; the South and Midwest should focus on Debris Burning and Arson.
	              </p>
        </div>
      </div>
    <br>
      <div>  
        <h3 class='section' >Historic Fire Causes by Seasonality</h3>
        <svg id="chart2" width="100%" height="350px"></svg>
        <!-- <script src="seasonality.js"></script> -->
    </div>
    <div id="spacer" style="height:47px; width:100%; clear:both;"></div>
          	    <p id="descr" align="left">
		            The stacked bar chart shows 6 most common wildfire causes in the US. It gives a very straightforward impression of wildfires causes with respect to seasonality. In general, arson and debris burning take up the largest portion of wildfires in Spring (March and April) while lightning strikes and campfire are two main threats during summer days (July and August). But lightning rarely causes wildfires in other seasons. Smoking and equipment use, on the other hand, show a relatively consistent rate in the whole year. 
	              </p>
    </div>
    <!-- </div>
      <img class="center-fit" src="fuego.jpg" alt="fuego" />
    </div> -->

  </div>
</template>


<script>
import * as d3 from "d3";

export default {
  name: "d3Layout",
  data: function() {
    return {
      seasonalityData: null,
      D3LayoutData: null
    };
  },
  methods: {
    D3Responsive() {
            var data = this.seasonalityData;

            var svg_elem = d3.select('#chart2'),
                outer_width = parseInt(svg_elem.style('width')),
                outer_height = parseInt(svg_elem.style('height'));

            var margin = {top: 10, right: 200, bottom: 30, left: 200},
                inner_width =  outer_width - margin.left - margin.right,
                inner_height = outer_height - margin.top - margin.bottom;

            var svg = svg_elem
                    .append('g')
                    .attr('transform', 'translate(' + margin.left + ', ' + margin.top + ')');

            var series = d3.stack()
                .keys(this.seasonalityData.columns.slice(1))
                (this.seasonalityData)
                .map(d => (d.forEach(v => v.key = d.key), d));

            var legends = series.map(d => d.key);

            var color = d3.scaleOrdinal()
                .domain(series.map(d => d.key))
                // .range(d3.schemeSpectral[series.length])
                .range(["#FB8072", "#FDB462", "#FFFFB3", "#8DD3C7", "#80B1D3", "#BEBADA"])
                .unknown("#ccc");

            var x = d3.scaleBand()
                .round(true)
                .paddingInner(0.05)
                .domain(this.seasonalityData.map(d => d.month))
                .range([0, inner_width]);
            
            svg.append("g")
                .attr('class', 'x axis')
                .style("font", "14px times")
                .style("font-family",  "Raleway")
                .attr("transform", "translate(0," + inner_height + ")")
                .call(d3.axisBottom(x));

            var y = d3.scaleLinear()
                // .domain([0, d3.max(series, d => d3.max(d, d => d[1]))])
                .domain([0, 1])
                .range([inner_height, 0])
                .nice();

            // y-axis label
            svg.append("g")
                .attr('class', 'y axis')
                .style("font", "14px times")
                .style("font-family",  "Raleway")
                .call(d3.axisLeft(y))
                .append('text')
                .attr('transform', 'rotate(-90)')
                .attr('x', -100)
                .attr('y', -50)
                .style('font-size', '18')
                .style('fill', '#fee0d2')
                .text('Percentage');

            svg.selectAll('.line')
                .data(this.seasonalityData)
                .enter()
                .append('line')
                .attr('class', 'line')
                .attr('x1', d => x(d.month) + x.bandwidth() / 2)
                .attr('y1', inner_height)
                .attr('x2', d => x(d.month) + x.bandwidth() / 2)
                .attr('y2', d => y(d3.sum(legends.map(k => d[k]))))
                .attr('stroke', '#aaa')
                .attr('stroke-width', '3px');

            svg.append("g")
                .selectAll("g")
                .data(series)
                .enter()
                .append('g')
                .attr('id', 'g-circle')
                .attr("fill", d => color(d.key))
                .selectAll("circle")
                .data(d => d)
                .enter()
                .append("circle")
                .attr('class', 'circle')
                .attr("cx", d => x(d.data.month) + x.bandwidth() / 2)
                .attr("cy", d => y(d[1]))
                .attr("r", 5);

            svg.append("g")
                .selectAll("g")
                .data(series)
                .enter()
                .append('g')
                .attr('id', 'g-rect')
                .attr("fill", d => color(d.key))
                .selectAll("rect")
                .data(d => d)
                .enter()
                .append('rect')
                .attr('class', 'rect')
                .attr("x", (d, i) => x(d.data.month))
                .attr("y", d => y(d[1]))
                .attr("height", d => y(d[0]) - y(d[1]))
                .attr("width", x.bandwidth())
                .attr('stroke', d => color(d.key))
                .attr('stroke-width', 2)
                // .attr('shape-rendering', "crispEdges")
                .attr("fill-opacity", 0.6)

            // create legends
            svg.selectAll('.legend')
                .data(legends)
                .enter()
                .append('rect')
                .attr('class', 'legend-bar')
                .attr('x', inner_width - 150)
                .attr('y', (d, i) => i * 20)
                .attr('height', 20)
                .attr('width', 50)
                .attr('fill', d => color(d))
                .attr('stroke-width', 3.5)
                .attr("fill-opacity", 0.8);

            svg.selectAll('.text')
                .data(legends)
                .enter()
                .append('text')
                .attr('class', 'legend-text')
                .attr('x', inner_width - 90)
                .attr('y', (d, i) => i * 20)
                .style('alignment-baseline', 'hanging')
                .style('text-anchor', 'start')
                .style('fill', '#fee0d2')
                .style('font-size', '15')
                .text(d => {
                  var lists = d.split('_')
                  console.log(lists)
                  for (var i in lists) {
                    lists[i] = lists[i][0].toUpperCase() + lists[i].substring(1)
                  }
                  return lists.join(' ')
                })
                
            resize();
            d3.select(window).on('resize', resize);
            
            function resize() {
                var new_width = parseInt(d3.select('#chart2').style('width')) - margin.left - margin.right;
                var new_height = parseInt(d3.select('#chart2').style('height')) - margin.top - margin.bottom;
                svg.attr('width', new_width).attr('height', new_height);

                x.range([0, new_width]);
                y.range([new_height, 0]).nice();

                svg.selectAll('.legend-bar')
                    .attr('x', new_width - 150 * new_width / inner_width)
                    .attr('y', (d, i) => i * 20 * new_height / inner_height)
                    .attr('height', 20 * new_height / inner_height)
                    .attr('width',  50 * new_width / inner_width);

                svg.selectAll('.legend-text')
                    .attr('x', new_width + 10 - 100 * new_width / inner_width)
                    .attr('y', (d, i) => i * 20 * new_height / inner_height);
            
                if (new_width < 750) {
                    svg.selectAll('#g-circle')
                        .data(series)
                        .selectAll('.circle')
                        .data(d => d)
                        .attr("cx", d => x(d.data.month) + x.bandwidth() / 2)
                        .attr("cy", d => y(d[1]))
                        .attr("r", 5);
            
                    svg.selectAll('.line')
                        .data(data)
                        .attr('x1', d => x(d.month) + x.bandwidth() / 2)
                        .attr('y1', new_height)
                        .attr('x2', d => x(d.month) + x.bandwidth() / 2)
                        .attr('y2', d => y(d3.sum(legends.map(k => d[k]))));
            
                    svg.select('.x.axis').style('display', 'none');
                    svg.select('.y.axis').style('display', 'none');
                    svg.selectAll('.rect').style('display', 'none');
                    svg.selectAll('.circle').style('display', 'initial');
                    svg.selectAll('.line').style('display', 'initial');

                } else {
                    svg.selectAll("#g-rect")
                        .data(series)
                        .selectAll("rect")
                        .data(d => d)
                        .attr("x", d => x(d.data.month))
                        .attr("y", d => y(d[1]))
                        .attr("height", d => y(d[0]) - y(d[1]))
                        .attr("width", x.bandwidth());
            
                    svg.select('.x.axis')
                        .attr('transform', 'translate(0,' + new_height + ')')
                        .call(d3.axisBottom(x));
            
                    svg.select('.y.axis')
                        .call(d3.axisLeft(y));
            
                    svg.select('.x.axis').style('display', 'initial');
                    svg.select('.y.axis').style('display', 'initial');
                    svg.selectAll('.circle').style('display', 'none');
                    svg.selectAll('.line').style('display', 'none');
                    svg.selectAll('.rect').style('display', 'initial');
                }
            };  
    },
    D3Layout() {
      var margin = { top: 150, right: 150, bottom: 100, left: 100 },
        width =
          Math.min(700, window.innerWidth - 10) - margin.left - margin.right,
        height = Math.min(
          width,
          window.innerHeight - margin.top - margin.bottom - 20
        );

      var color = d3
        .scaleOrdinal()
        .range(["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3"]);

      var options = {
        w: width,
        h: height,
        margin: margin,
        maxValue: 0.5,
        levels: 5,
        roundStrokes: true,
        color: color
      };

      var id = "#radarChart";

      var data = [
        [
          //West
          { axis: "Arson", value: 0.09, color: "#66c2a5" },
          { axis: "Debris Burning", value: 0.1, color: "#66c2a5" },
          { axis: "Lightning", value: 0.5, color: "#66c2a5" }, //.53
          { axis: "Equipment Use", value: 0.17, color: "#66c2a5" },
          { axis: "Campfire", value: 0.11, color: "#66c2a5" },
          { axis: "Smoking", value: 0.04, color: "#66c2a5" }
        ],
        [
          //Midwest
          { axis: "Arson", value: 0.26, color: "#fc8d62" },
          { axis: "Debris Burning", value: 0.43, color: "#fc8d62" },
          { axis: "Lightning", value: 0.08, color: "#fc8d62" },
          { axis: "Equipment Use", value: 0.14, color: "#fc8d62" },
          { axis: "Campfire", value: 0.06, color: "#fc8d62" },
          { axis: "Smoking", value: 0.04, color: "#fc8d62" }
        ],
        [
          //South
          { axis: "Arson", value: 0.28, color: "#8da0cb" },
          { axis: "Debris Burning", value: 0.47, color: "#8da0cb" },
          { axis: "Lightning", value: 0.07, color: "#8da0cb" },
          { axis: "Equipment Use", value: 0.1, color: "#8da0cb" },
          { axis: "Campfire", value: 0.03, color: "#8da0cb" },
          { axis: "Smoking", value: 0.04, color: "#8da0cb" }
        ],
        [
          //Northeast
          { axis: "Arson", value: 0.36, color: "#e78ac3" },
          { axis: "Debris Burning", value: 0.23, color: "#e78ac3" },
          { axis: "Lightning", value: 0.1, color: "#e78ac3" },
          { axis: "Equipment Use", value: 0.09, color: "#e78ac3" },
          { axis: "Campfire", value: 0.08, color: "#e78ac3" },
          { axis: "Smoking", value: 0.13, color: "#e78ac3" }
        ]
      ];

      var cfg = {
        w: 600, //Width of the circle
        h: 600, //Height of the circle
        margin: { top: 20, right: 20, bottom: 20, left: 20 }, //The margins of the SVG
        levels: 3, //How many levels or inner circles should there be drawn
        maxValue: 0.5, //What is the value that the biggest circle will represent
        labelFactor: 1.25, //How much farther than the radius of the outer circle should the labels be placed
        wrapWidth: 60, //The number of pixels after which a label needs to be given a new line
        opacityArea: 0.15, //The opacity of the area of the blob
        dotRadius: 4, //The size of the colored circles of each blog
        opacityCircles: .04, //The opacity of the circles of each blob
        strokeWidth: 2, //The width of the stroke around each blob
        roundStrokes: false, //If true the area and stroke will follow a round path (cardinal-closed)
        color: d3
          .scaleOrdinal()
          .range(["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3"]) //d3.scale.category10()	//Color function
      };

      //Put all of the options into a variable called cfg
      if ("undefined" !== typeof options) {
        for (var i in options) {
          if ("undefined" !== typeof options[i]) {
            cfg[i] = options[i];
          }
        } //for i and
      } //if

      //If the supplied maxValue is smaller than the actual one, replace by the max in the data
      var maxValue = Math.max(
        cfg.maxValue,
        d3.max(data, function(i) {
          return d3.max(
            i.map(function(o) {
              return o.value;
            })
          );
        })
      );

      var allAxis = data[0].map(function(i, j) {
          return i.axis;
        }), //Names of each axis
        total = allAxis.length, //The number of different axes
        radius = Math.min(cfg.w / 2, cfg.h / 2), //Radius of the outermost circle
        Format = d3.format(",.0%"), //Percentage formatting
        angleSlice = (Math.PI * 2) / total; //The width in radians of each "slice"

      //Scale for the radius
      var rScale = d3
        .scaleLinear()
        .range([0, radius])
        .domain([0, maxValue]);

      /////////////////////////////////////////////////////////
      //////////// Create the container SVG and g /////////////
      /////////////////////////////////////////////////////////

      //Remove whatever chart with the same id/class was present before
      // d3.select(id).select("svg").remove();

      //Initiate the radar chart SVG
      var svg = d3
        .select(id)
        .append("svg")
        .attr("width", cfg.w + cfg.margin.left + cfg.margin.right)
        .attr("height", cfg.h + cfg.margin.top + cfg.margin.bottom)
        .attr("class", "radar" + id)
        .style('background-color','none');
      //Append a g element
      var g = svg
        .append("g")
        .style('background-color','none')
        .attr(
          "transform",
          "translate(" +
            (cfg.w / 2 + cfg.margin.left) +
            "," +
            (cfg.h / 2 + cfg.margin.top) +
            ")"
        );

      /////////////////////////////////////////////////////////
      ////////// Glow filter for some extra pizzazz ///////////
      /////////////////////////////////////////////////////////

      //Filter for the outside glow
      var filter = g
          .append("defs")
          .append("filter")
          .attr("id", "glow"),
        feGaussianBlur = filter
          .append("feGaussianBlur")
          .attr("stdDeviation", "2.5")
          .attr("result", "coloredBlur"),
        feMerge = filter.append("feMerge"),
        feMergeNode_1 = feMerge.append("feMergeNode").attr("in", "coloredBlur"),
        feMergeNode_2 = feMerge
          .append("feMergeNode")
          .attr("in", "SourceGraphic");

      /////////////////////////////////////////////////////////
      /////////////// Draw the Circular grid //////////////////
      /////////////////////////////////////////////////////////

      //Wrapper for the grid & axes
      var axisGrid = g.append("g").attr("class", "axisWrapper");

      //Draw the background circles
      axisGrid
        .selectAll(".levels")
        .data(d3.range(1, cfg.levels + 1).reverse())
        .enter()
        .append("circle")
        .attr("class", "gridCircle")
        .attr("r", function(d, i) {
          return (radius / cfg.levels) * d;
        })
        .style("fill", "#CDCDCD")
        .style("stroke", "black")  //.style("stroke", "#CDCDCD")
        .style("fill-opacity", cfg.opacityCircles)   //.style("fill-opacity", cfg.opacityCircles)
        .style("filter", "url(#glow)");

      //Text indicating at what % each level is
      axisGrid
        .selectAll(".axisLabel")
        .data(d3.range(1, cfg.levels + 1).reverse())
        .enter()
        .append("text")
        .attr("class", "axisLabel")
        .attr("x", 4)
        .attr("y", function(d) {
          return (-d * radius) / cfg.levels;
        })
        .attr("dy", "0.4em")
        .style("font-size", "12px")
        .attr("fill", "white")   //.attr("fill", "#737373")
        .text(function(d, i) {
          return Format((maxValue * d) / cfg.levels);
        });

      /////////////////////////////////////////////////////////
      //////////////////// Draw the axes //////////////////////
      /////////////////////////////////////////////////////////

      //Create the straight lines radiating outward from the center
      var axis = axisGrid
        .selectAll(".axis")
        .data(allAxis)
        .enter()
        .append("g")
        .attr("class", "axis");
      //Append the lines
      axis
        .append("line")
        .attr("x1", 0)
        .attr("y1", 0)
        .attr("x2", function(d, i) {
          return (
            rScale(maxValue * 1.1) * Math.cos(angleSlice * i - Math.PI / 2)
          );
        })
        .attr("y2", function(d, i) {
          return (
            rScale(maxValue * 1.1) * Math.sin(angleSlice * i - Math.PI / 2)
          );
        })
        .attr("class", "line")
        .style("stroke", "#fee6ce")
        .style("stroke-width", "2px");

      //Append the labels at each axis
      axis
        .append("text")
        .attr("class", "legend")
        .style("font-size", "13.4px")
        .style("font-weight", "bold")
        .attr("text-anchor", "middle")
        .attr("dy", "0.35em")
        .attr("x", function(d, i) {
          return (
            rScale(maxValue * cfg.labelFactor) *
            Math.cos(angleSlice * i - Math.PI / 2)
          );
        })
        .attr("y", function(d, i) {
          return (
            rScale(maxValue * cfg.labelFactor) *
            Math.sin(angleSlice * i - Math.PI / 2)
          );
        })
        .text(function(d) {
          return d;
        })
        .attr("fill", "#fee6ce")
        .call(wrap, cfg.wrapWidth);

      /////////////////////////////////////////////////////////
      ///////////// Draw the radar chart blobs ////////////////
      /////////////////////////////////////////////////////////

      //The radial line function
      var radarLine = d3
        .radialLine() //d3.svg.line.radial()
        // .interpolate("linear-closed")
        .curve(d3.curveLinearClosed)
        .radius(function(d) {
          return rScale(d.value);
        })
        .angle(function(d, i) {
          return i * angleSlice;
        });

      if (cfg.roundStrokes) {
        radarLine.curve(d3.curveCardinalClosed);
      }

      //Create a wrapper for the blobs
      var blobWrapper = g
        .selectAll(".radarWrapper")
        .data(data)
        .enter()
        .append("g")
        .attr("class", "radarWrapper");

      //Append the backgrounds
      blobWrapper
        .append("path")
        .attr("class", "radarArea")
        .attr("d", function(d, i) {
          return radarLine(d);
        })
        .style("fill", function(d, i) {
          return cfg.color(i);
        })
        .style("fill-opacity", cfg.opacityArea)
        .on("mouseover", function(d, i) {
          //Dim all blobs
          d3.selectAll(".radarArea")
            .transition()
            .duration(200)
            .style("fill-opacity", 0.1);
          //Bring back the hovered over blob
          d3.select(this)
            .transition()
            .duration(200)
            .style("fill-opacity", 0.7);
        })
        .on("mouseout", function() {
          //Bring back all blobs
          d3.selectAll(".radarArea")
            .transition()
            .duration(200)
            .style("fill-opacity", cfg.opacityArea);
        });

      //Create the outlines
      blobWrapper
        .append("path")
        .attr("class", "radarStroke")
        .attr("d", function(d, i) {
          return radarLine(d);
        })
        .style("stroke-width", cfg.strokeWidth + "px")
        .style("stroke", function(d, i) {
          return cfg.color(i);
        })
        .style("fill", "none")
        //.style("filter", "url(#glow)");

      //Append the circles
      blobWrapper
        .selectAll(".radarCircle")
        .data(function(d, i) {
          return d;
        })
        .enter()
        .append("circle")
        .attr("class", "radarCircle")
        .attr("r", cfg.dotRadius)
        .attr("cx", function(d, i) {
          return rScale(d.value) * Math.cos(angleSlice * i - Math.PI / 2);
        })
        .attr("cy", function(d, i) {
          return rScale(d.value) * Math.sin(angleSlice * i - Math.PI / 2);
        })
        // .style("fill", function (d, i,j) { return cfg.color(j); })
        .style("fill", function(d, i, j) {
          return d.color;
        })
        .style("fill-opacity", 0.8)
        .on("mouseover", function() {
          d3.select(this).attr("fill", "#9e9ac8");
        })
        .on("mouseout", function() {
          d3.select(this).attr("fill", "black");
        })
        .append("title")
        .text(function(d, i) {
          return Format(d.value);
        });

      /////////////////////////////////////////////////////////
      //////// Append invisible circles for tooltip ///////////
      /////////////////////////////////////////////////////////

      //Wrapper for the invisible circles on top
      var blobCircleWrapper = g
        .selectAll(".radarCircleWrapper")
        .data(data)
        .enter()
        .append("g")
        .attr("class", "radarCircleWrapper");

      var Format2 = d3.format("%");

      //Append a set of invisible circles on top for the mouseover pop-up
      // blobCircleWrapper.selectAll(".radarInvisibleCircle")
      // 	.data(function (d, i) { return d; })
      // 	.enter().append("circle")
      // 	.attr("class", "radarInvisibleCircle")
      // 	.attr("r", cfg.dotRadius * 1.5)
      // 	.attr("cx", function (d, i) { return rScale(d.value) * Math.cos(angleSlice * i - Math.PI / 2); })
      // 	.attr("cy", function (d, i) { return rScale(d.value) * Math.sin(angleSlice * i - Math.PI / 2); })
      // 	.style("fill", "none")
      // 	.style("pointer-events", "all")
      // 	.on("mouseover", function (d, i) {
      // 		newX = parseFloat(d3.select(this).attr('cx')) - 10;
      // 		newY = parseFloat(d3.select(this).attr('cy')) - 10;

      // 		tooltip
      // 			.attr('x', newX)
      // 			.attr('y', newY)
      // 			// .text(Format(d.value))
      // 			.text(function() { return Format2(d.value); })
      // 			.transition().duration(200)
      // 			.style('opacity', 1);

      // 	})
      // 	.on("mouseout", function () {
      // 		tooltip.transition().duration(200)
      // 			.style("opacity", 0);
      // 	});

      //Set up the small tooltip for when you hover over a circle
      var tooltip = g
        .append("text")
        .attr("class", "tooltip")
        .style("font-family", "sans-serif")
        .style("font-size", "13px")
        .style("opacity", 0);

      /////////////////////////////////////////////////////////
      /////////////////// Helper Function /////////////////////
      /////////////////////////////////////////////////////////

      //Taken from http://bl.ocks.org/mbostock/7555321
      //Wraps SVG text
      function wrap(text, width) {
        text.each(function() {
          var text = d3.select(this),
            words = text
              .text()
              .split(/\s+/)
              .reverse(),
            word,
            line = [],
            lineNumber = 0,
            lineHeight = 1.4, // ems
            y = text.attr("y"),
            x = text.attr("x"),
            dy = parseFloat(text.attr("dy")),
            tspan = text
              .text(null)
              .append("tspan")
              .attr("x", x)
              .attr("y", y)
              .attr("dy", dy + "em");

          while ((word = words.pop())) {
            line.push(word);
            tspan.text(line.join(" "));
            if (tspan.node().getComputedTextLength() > width) {
              line.pop();
              tspan.text(line.join(" "));
              line = [word];
              tspan = text
                .append("tspan")
                .attr("x", x)
                .attr("y", y)
                .attr("dy", ++lineNumber * lineHeight + dy + "em")
                .text(word);
            }
          }
        });
      } //wrap

      /////////////////////////////////////////
      //          Draw the Legend            //
      /////////////////////////////////////////

      var legend_labs = ["West", "Midwest", "South", "Northeast"];
      var legend_colors = ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3"];

      //Draw Legend Box
      var box = g.append("g").attr("class", "axisWrapper");
      box
        .append("rect")
        .attr("x", 160)
        .attr("y", 175)
        .attr("width", 115)
        .attr("height", 110)
        .style("fill", "black")
        .style("stroke", "#fee6ce");

      var legends = g.append("g").attr("class", "axisWrapper");

      //Draw the background circles
      legends
        .selectAll(".legs")
        .data(legend_colors)
        .enter()
        .append("rect")
        .attr("x", 170)
        .attr("y", function(d, i) {
          return i * 25 + 185;
        })
        .attr("width", 15)
        .attr("height", 15)
        .style("fill", function(d) {
          return d;
        })
        .style("stroke", function(d) {
          return d;
        })
        .style("fill-opacity", .75);

      legends
        .selectAll(".labs")
        .data(legend_labs)
        .enter()
        .append("text")
        .attr("text-anchor", "start")
        .attr("alignment-baseline", "hanging")
        .attr("x", 195)
        .attr("y", function(d, i) {
          return i * 25 + 187;
        })
        .attr("class", "legendText")
        .text(function(d) {
          return d;
        });

      /////////////////////////////
      //        Title            //
      /////////////////////////////

      var radartitle = g.append("g").attr("class", "axisWrapper");

      radartitle
        .append("text")
        .attr("text-anchor", "middle")
        .attr("alignment-baseline", "hanging")
        .attr("x", 0)
        .attr("y", -358)
        .attr("class", "radarTitle")
        .text("Historic Fire Causes by Region")
        .style('font-size', '26px');

      /////////////////////////////
      //        INFO BOX         //
      /////////////////////////////

      var info = g.append("g").attr("class", "axisWrapper");

      info
        .append("text")
        .attr("text-anchor", "middle")
        .attr("alignment-baseline", "hanging")
        .attr("x", 215)
        .attr("y", 300)
        .attr("class", "infoBox")
        .text("More Info?")
        .on("mouseover", function() {
          d3.select(this).attr("fill", "#9e9ac8");
        })
        .on("mouseout", function() {
          d3.select(this).attr("fill", "#fee6ce");
        })
        .append("title")
        .text(
          "Hover your cursor over an individual data point in order to see its value."
        );
    }
  },
  mounted: function() {
    console.log("mounted");

    if (!this.$store.state.vueD3LayoutData) {
      d3.json("1999_2015.json").then(data => {
        this.D3LayoutData = data;
        this.$store.commit("vueD3LayoutData", this.D3LayoutData);

        this.D3Layout();
      });
    } else {
      this.D3LayoutData = this.$store.state.vueD3LayoutData;
      this.D3Layout();
    }

    if (!this.$store.state.seasonalityData) {
            var month_name = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            
            d3.csv('seasonality.csv', function(d) {
                return {
                    month: month_name[+d.month - 1],
                    arson: +d.arson,
                    campfire: +d.campfire,
                    debris_burning: + d.debris_burning,
                    equipment_use: +d.equipment_use,
                    lightning: +d.lightning,
                    smoking: +d.smoking
                }
            }).then(data => {
                this.seasonalityData = data;      
                this.$store.commit('seasonalityData', this.seasonalityData);
                this.D3Responsive();
            });
        } else {
            this.seasonalityData = this.$store.state.seasonalityData;
            this.D3Responsive();
        }
  }
};
</script>

<!-- "scoped" attribute limits CSS to this component only -->
<style scoped>
>>> #radarChart {
  cursor: pointer;
  background-color: black;
}

>>> #spacer {
  background-color: black;
}

>>> .radarTitle {
  font-family: "Raleway", sans-serif;
  fill: #fee6ce;
  font-weight: bold;
  font-size: 20px;
}

>>> .legendText {
  font-family: "Raleway", sans-serif;
  fill: #fee6ce;
  font-size: 14px;
}

>>> .axisLabel {
  font-family: "Raleway", sans-serif;
  fill: #fee6ce;
  font-size: 15px;
  font-weight: bolder;
}

>>> .legend {
  background-color: #fff;
  border-radius: 3px;
  top: 46px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  font: 12px/20px "Helvetica Neue", Arial, Helvetica, sans-serif;  
  padding: 10px;
  position: absolute;
  right: -10px;
  z-index: 1;
  fill: #fee6ce;
}

>>> .tooltip text {
  font-family: "Raleway", sans-serif;
  fill: #333333;
  font-size: 13px;
}

>>> .infoBox, h3 {
  font-family: "Raleway", sans-serif;
  fill: #fee6ce;
  font-weight: bold;
}

>>> img {
    padding: 0;
    display: block;
    margin: 0 auto;
    max-height: 100%;
    max-width: 100%;
}

>>> #descr {
  padding: 15px 200px 15px 200px;
}


</style>
