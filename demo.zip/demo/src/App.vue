<template>
  <div id="app" :style="{ 'backgroundColor': 'black'}" class="App">
    <div id="nav">
      <span>&#128293;</span>
      <router-link to="/">Home</router-link> <span>&#128293;</span>
      <router-link to="/d3map">Historic Fire Map</router-link> <span>&#128293;</span>
      <router-link to="/d3interaction">Federal Funding</router-link> <span>&#128293;</span>
      <router-link to="/mapbox">Historic Fire Counts</router-link> <span>&#128293;</span>
      <router-link to="/d3layout">Fire Causes</router-link> <span>&#128293;</span>
      <router-link to="/conclusion">Conclusion</router-link> <span>&#128293;</span>
      <!-- <router-link to="/d3responsive">Fire Causes by Seasonalities</router-link> -->
      
    </div>
    <router-view/>
    <div id="nav">
      <span>&#128293;</span>
      <router-link to="/" @click.native="scrollToTop">Home</router-link> <span>&#128293;</span>
      <router-link to="/d3map" @click.native="scrollToTop">Historic Fire Map</router-link> <span>&#128293;</span>
      <router-link to="/d3interaction" @click.native="scrollToTop">Federal Funding</router-link> <span>&#128293;</span>
      <router-link to="/mapbox" @click.native="scrollToTop">Historic Fire Counts</router-link> <span>&#128293;</span>
      <router-link to="/d3layout" @click.native="scrollToTop">Fire Causes</router-link> <span>&#128293;</span>
      <router-link to="/conclusion" @click.native="scrollToTop">Conclusion</router-link> <span>&#128293;</span>
      <!-- <router-link to="/d3responsive">Fire Causes by Seasonalities</router-link> -->
      
    </div>
  </div>
</template>
<script>
export default {
    name:'App',
    methods: { 
        scrollToTop() {
            window.scrollTo(0,0);
        }
    }
}
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #fee0d2;
  background-color: black;
  font-size: 100%;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #fee0d2;
}

#nav a.router-link-exact-active {
  color: #fc9272;
  font-weight: 900;
}
</style>
