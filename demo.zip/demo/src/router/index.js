import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'


Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/d3map',
    name: 'D3Map',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/D3Map.vue')
  },
  {
    path: '/d3animation',
    name: 'D3Animation',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/D3Animation.vue')
  },  
  {
    path: '/d3animation2',
    name: 'D3Animation2',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/D3Animation2.vue')
  },
  {
    path: '/d3interaction',
    name: 'D3Interaction',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/D3Interaction.vue')
  },
  {
    path: '/d3layout',
    name: 'D3Layout',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/D3Layout.vue')
  },
  {
    path: '/d3responsive',
    name: 'D3Responsive',
    component: () => import('../views/D3Responsive.vue')
  },
  {
    path: '/mapbox',
    name: 'Mapbox',
    component: () => import('../views/Mapbox.vue')
  },
  {
    path: '/conclusion',
    name: 'Conclusion',
    component: () => import('../views/Conclusion.vue')
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
