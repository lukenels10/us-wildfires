import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    seasonalityData: null
  },
  mutations: {
    vueD3MapData(state, payload) {
      state.vueD3MapData = payload;
    },
    vueD3AnimationData(state, payload) {
      state.vueD3AnimationData = payload;
    },
    vueD3Animation2Data(state, payload) {
      state.vueD3Animation2Data = payload;
    },
    vueD3InteractionData(state, payload) {
      state.vueD3InteractionData = payload;
    },
    vueD3LayoutData(state, payload) {
      state.vueD3LayoutData = payload;
    },
    seasonalityData(state, payload) {
      state.seasonalityData = payload;
    }
  },
  actions: {
  },
  modules: {
  }
})
