var promises = [];
var files = ['data/us.json', 'data/firesgeojson.json'];
files.forEach(url => promises.push(d3.json(url)));  //🚧  explain

//console.log(promises)
Promise.all(promises).then(function (values) {  //🚧  explain
var us = values[0];
var data = values[1];

//console.log(data)

//get all distinct cause
var lookup = {};
var items = data.features;
var result = [];

for (var item, i = 0; item=items[i++];){
    var cause = item.properties.STAT_CAUSE_DESCR;

    if (!(cause in lookup)){
        lookup[cause] = 1
        result.push(cause)
    }
}
console.log(result)

//introduce color scale
var scale = d3.scaleOrdinal()
                .domain(result)
                .range(d3.schemeCategory9)

var svg = d3.select('#chart')
            .style('background-color','black'),
    width = +svg.attr('width'),
    height = +svg.attr('height');

var projection = d3.geoAlbersUsa()
    .fitSize([width, height], us);
    
var path = d3.geoPath().projection(projection);

var graticule = d3.geoGraticule()  //🚧  explain: Constructs a geometry generator for creating graticules: a uniform grid of meridians and parallels for showing projection distortion and set the major and minor steps
        .step([10, 10]);
        
svg.append('path')
    .datum(graticule)  //🚧  explain: associate path tag with graticule
    .attr('class', 'graticule')
    .attr('d', path);


// projector for wildfire data

// svg.append('path')
// 		.attr('fill', 'rgb(255,190,232)')
// 		.attr('stroke', 'black')
// 		.attr('d', path(us.features[4]));  //generate geographic path

svg.selectAll('.states')
    .data(us.features)  //🚧  explain: associate path with each feature in json
    .enter()
    .append('path')
    .attr('fill', d => 'white')  //🚧  explain: fill each state with white
    //.attr('fill', d => d.id == '06' ? '#FFCC00' : 'white')  //🚧  try and explain: fill California with yellow
    .attr('class', 'states')
    .attr('d', path);

// symbols
svg.append('g')
    //.attr('fill', 'brown')
    .attr('fill-opacity', 0.5)
    .attr('stroke', '#fff')
    .attr('stroke-width', 0.5)
    .selectAll('circle')
    .data(data.features)
    .enter()
    .append('circle')
    .attr('cx', d=>projection(d.geometry.coordinates)[0])
    .attr('cy', d=>projection(d.geometry.coordinates)[1])
    .attr('r', 5)
    .attr('fill',d=>scale(d.properpties.STAT_CAUSE_DESCR));



//format = d3.format(',.0f')

//🚧  explain
//data = new Map(data.slice(1).map(([population, state, county]) => [state + county, +population]))

//🚧  explain
//radius = d3.scaleSqrt([0, d3.quantile([...data.values()].sort(d3.ascending), 0.985)], [0, 15]);
//console.log([...data.values()])



//🚧  explain nation border
// svg.append('path')
//   .datum(topojson.feature(us, us.objects.nation))
//   .attr('fill', '#ccc')
//   .attr('d', path);

// 🚧  explain state borders
// svg.append('path')
//   .datum(topojson.mesh(us, us.objects.states, (a, b) => a !== b))
//   .attr('fill', 'none')
//   .attr('stroke', 'white')
//   .attr('stroke-linejoin', 'round')
//   .attr('d', path);

//🚧  legend
// const legend = svg.append('g')
//   .attr('fill', '#777')
//   .attr('transform', 'translate(925,608)')
//   .attr('text-anchor', 'middle')
//   .style('font', '10px sans-serif')
//   .selectAll('g')
//   .data([1e6, 5e6, 1e7])
//   .join('g');

// legend.append('circle')
//   .attr('fill', 'none')
//   .attr('stroke', '#ccc')
//   .attr('cy', d => -radius(d))
//   .attr('r', radius);

// legend.append('text')
//   .attr('y', d => -2 * radius(d))
//   .attr('dy', '1.3em')
//   .text(d3.format('.1s'));			
});